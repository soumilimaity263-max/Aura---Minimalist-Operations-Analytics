import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  INITIAL_TRANSACTIONS,
  PERIOD_METRICS,
  CHART_DATA_BY_PERIOD,
  INITIAL_ANOMALIES,
  INITIAL_WEBHOOKS,
  USER_PROFILE,
} from './data/mockData';
import {
  TimePeriod,
  Transaction,
  ToastMessage,
  AnomalyAlert,
  WebhookLog,
} from './types/dashboard';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { MetricCard } from './components/MetricCard';
import { RevenueChart } from './components/RevenueChart';
import { TransactionTable } from './components/TransactionTable';
import { TransactionDrawer } from './components/TransactionDrawer';
import { NewTransactionModal } from './components/NewTransactionModal';
import { RegionalMarkets } from './components/RegionalMarkets';
import { CustomersView } from './components/CustomersView';
import { PayoutsView } from './components/PayoutsView';
import { SettingsView } from './components/SettingsView';
import { WebhooksView } from './components/WebhooksView';
import { CommandPalette } from './components/CommandPalette';
import { AnomalyBanner } from './components/AnomalyBanner';
import { ToastContainer } from './components/Toast';

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('aura-theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Apply dark class to html document element
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('aura-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('aura-theme', 'light');
    }
  }, [isDark]);

  // Tab & View State
  const [currentTab, setCurrentTab] = useState<NavTab>('overview');
  const [period, setPeriod] = useState<TimePeriod>('30d');
  const [searchQuery, setSearchQuery] = useState('');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [density, setDensity] = useState<'comfortable' | 'compact'>('comfortable');

  // Transactions State
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [selectedTxn, setSelectedTxn] = useState<Transaction | null>(null);
  const [isNewTxnOpen, setIsNewTxnOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Anomaly Alerts State
  const [anomalies, setAnomalies] = useState<AnomalyAlert[]>(INITIAL_ANOMALIES);

  // Webhooks State
  const [webhooks, setWebhooks] = useState<WebhookLog[]>(INITIAL_WEBHOOKS);

  // Toast Notification State
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback(
    (title: string, description?: string, type: 'success' | 'info' | 'warning' = 'success') => {
      const id = `${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      setToasts((prev) => [...prev, { id, title, description, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3600);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        setSidebarCollapsed((prev) => !prev);
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 't') {
        e.preventDefault();
        setIsDark((prev) => !prev);
      } else if (e.key === 'Escape') {
        setSelectedTxn(null);
        setIsNewTxnOpen(false);
        setIsCommandPaletteOpen(false);
        setMobileNavOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle New Transaction Creation
  const handleCreateTransaction = (newTxn: Transaction) => {
    setTransactions((prev) => [newTxn, ...prev]);
    // Also simulate a real webhook event dispatch for payment.settled
    const newLog: WebhookLog = {
      id: `WH-${Math.floor(9100 + Math.random() * 900)}`,
      event: 'payment.settled',
      url: 'https://api.vanguard-sys.com/v1/payments/webhook',
      statusCode: 200,
      durationMs: Math.floor(35 + Math.random() * 25),
      timestamp: 'Just now',
      attempts: 1,
      payloadSummary: JSON.stringify({
        id: newTxn.id,
        amount: newTxn.amount,
        status: newTxn.status,
        customer: newTxn.customer.name,
      }),
    };
    setWebhooks((prev) => [newLog, ...prev]);

    addToast(
      'Transaction Recorded',
      `${newTxn.id} for ${newTxn.currency} ${newTxn.amount.toLocaleString()} settled & webhook dispatched.`,
      'success'
    );
  };

  // Handle Refund
  const handleRefundTransaction = (id: string) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'refunded' as const } : t))
    );
    addToast('Refund Processed', `Transaction ${id} refunded to source payment instrument.`, 'info');
  };

  // Handle Anomaly Alert Actions
  const handleDismissAnomaly = (id: string) => {
    setAnomalies((prev) => prev.filter((a) => a.id !== id));
    addToast('Alert Acknowledged', 'Telemetry notification dismissed.', 'info');
  };

  const handleResolveAnomaly = (id: string) => {
    setAnomalies((prev) =>
      prev.map((a) => (a.id === id ? { ...a, resolved: true } : a))
    );
    addToast('Mitigation Executed', 'Traffic re-routed to backup gateway.', 'success');
  };

  // Webhook Simulator Actions
  const handleTriggerTestWebhook = (event: string) => {
    const newLog: WebhookLog = {
      id: `WH-${Math.floor(9200 + Math.random() * 800)}`,
      event: event as any,
      url: 'https://api.auracloud.io/sandbox/receiver',
      statusCode: 200,
      durationMs: Math.floor(28 + Math.random() * 30),
      timestamp: 'Just now',
      attempts: 1,
      payloadSummary: JSON.stringify({
        event,
        source: 'dashboard.sandbox',
        timestamp: new Date().toISOString(),
        verified: true,
      }),
    };
    setWebhooks((prev) => [newLog, ...prev]);
    addToast('Webhook Dispatched', `Simulated ${event} event successfully delivered.`, 'success');
  };

  const handleRetryWebhook = (id: string) => {
    setWebhooks((prev) =>
      prev.map((log) =>
        log.id === id
          ? {
              ...log,
              statusCode: 200,
              attempts: log.attempts + 1,
              timestamp: 'Just now (Retried)',
            }
          : log
      )
    );
    addToast('Webhook Re-delivered', `Payload for ${id} re-transmitted with status HTTP 200 OK.`, 'success');
  };

  // CSV Export utility
  const handleExportCSV = (dataset: Transaction[] = transactions) => {
    const headers = [
      'Transaction ID',
      'Customer Name',
      'Customer Email',
      'Plan',
      'Amount',
      'Currency',
      'Status',
      'Date',
      'Payment Method',
      'Fees',
      'Region',
    ];

    const rows = dataset.map((t) => [
      t.id,
      `"${t.customer.name}"`,
      t.customer.email,
      t.plan,
      t.amount,
      t.currency,
      t.status,
      `"${t.date}"`,
      `"${t.paymentMethod}"`,
      t.fees,
      t.region,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `aura-transactions-${period}-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    addToast('Dataset Exported', `Exported ${dataset.length} transactions as CSV.`, 'success');
  };

  // Current metric set
  const currentMetrics = PERIOD_METRICS[period];
  const chartData = CHART_DATA_BY_PERIOD[period];

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 flex flex-col antialiased selection:bg-neutral-900 selection:text-white dark:selection:bg-neutral-100 dark:selection:text-neutral-900">
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
        />

        {/* Primary Viewport Area */}
        <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
          {/* Top Bar Header */}
          <Header
            currentTab={currentTab}
            period={period}
            onPeriodChange={setPeriod}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            isDark={isDark}
            onToggleTheme={() => setIsDark(!isDark)}
            onOpenMobileNav={() => setMobileNavOpen(true)}
            onOpenNewTransaction={() => setIsNewTxnOpen(true)}
            onExportCurrentView={() => handleExportCSV()}
            onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
          />

          {/* Main Content Workspace */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
            {/* Real-Time Live Telemetry Alerts Banner */}
            <AnomalyBanner
              anomalies={anomalies}
              onDismiss={handleDismissAnomaly}
              onResolve={handleResolveAnomaly}
            />

            {/* View 1: Operations Overview */}
            {currentTab === 'overview' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                {/* Metrics 4-Col Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {currentMetrics.map((metric) => (
                    <MetricCard key={metric.title} metric={metric} />
                  ))}
                </div>

                {/* Primary Chart Area & Regional Breakdown */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                  <div className="lg:col-span-2">
                    <RevenueChart data={chartData} period={period} />
                  </div>
                  <div className="lg:col-span-1">
                    <RegionalMarkets />
                  </div>
                </div>

                {/* Real-time Ledger Section */}
                <div>
                  <div className="flex items-center justify-between mb-3 px-1">
                    <div>
                      <h2 className="text-sm font-semibold tracking-tight text-neutral-900 dark:text-neutral-100">
                        Recent Settled Transactions
                      </h2>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">
                        Live stream of verified payments and automated bank sweeps.
                      </p>
                    </div>
                    <button
                      onClick={() => setCurrentTab('ledger')}
                      className="text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white transition-colors"
                    >
                      View all in ledger →
                    </button>
                  </div>

                  <TransactionTable
                    transactions={transactions}
                    onSelectTransaction={setSelectedTxn}
                    density={density}
                    onToggleDensity={() =>
                      setDensity(density === 'comfortable' ? 'compact' : 'comfortable')
                    }
                    onExportFilteredCSV={handleExportCSV}
                    onShowToast={addToast}
                  />
                </div>
              </div>
            )}

            {/* View 2: Full Transactions Ledger */}
            {currentTab === 'ledger' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 tracking-tight">
                    Transactions & Audit Ledger
                  </h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Filter, audit, and reconcile client payments with full cryptographic hashes and receipt downloads.
                  </p>
                </div>

                <TransactionTable
                  transactions={transactions}
                  onSelectTransaction={setSelectedTxn}
                  density={density}
                  onToggleDensity={() =>
                    setDensity(density === 'comfortable' ? 'compact' : 'comfortable')
                  }
                  onExportFilteredCSV={handleExportCSV}
                  onShowToast={addToast}
                />
              </div>
            )}

            {/* View 3: Customers Directory */}
            {currentTab === 'customers' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 tracking-tight">
                    Counterparty Directory & Accounts
                  </h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Manage active enterprise subscriptions, inspect contract specs, and drill into customer settlement histories.
                  </p>
                </div>
                <CustomersView
                  transactions={transactions}
                  onSelectTransaction={setSelectedTxn}
                  onShowToast={addToast}
                />
              </div>
            )}

            {/* View 4: Payouts & Treasury */}
            {currentTab === 'payouts' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 tracking-tight">
                    Treasury Reserves & Bank Disbursements
                  </h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Monitor available liquidity, rolling escrow requirements, and automated wire clearing schedules.
                  </p>
                </div>
                <PayoutsView onShowToast={addToast} />
              </div>
            )}

            {/* View 5: Webhooks & Developer Hub */}
            {currentTab === 'webhooks' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 tracking-tight">
                    Webhooks & Developer Event Dispatcher
                  </h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Simulate production event dispatches, verify HMAC signatures, and inspect decrypted JSON payloads.
                  </p>
                </div>
                <WebhooksView
                  webhooks={webhooks}
                  onTriggerTestWebhook={handleTriggerTestWebhook}
                  onRetryWebhook={handleRetryWebhook}
                  onShowToast={addToast}
                />
              </div>
            )}

            {/* View 6: Settings & Platform Configuration */}
            {currentTab === 'settings' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <h2 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 tracking-tight">
                    Platform Settings & Credentials
                  </h2>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    Configure webhook dispatch endpoints, copy cryptographic keys, and set accounting currencies.
                  </p>
                </div>
                <SettingsView onShowToast={addToast} />
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Transaction Slide-over Inspector */}
      <TransactionDrawer
        transaction={selectedTxn}
        onClose={() => setSelectedTxn(null)}
        onRefund={handleRefundTransaction}
        onShowToast={addToast}
      />

      {/* Record New Transaction Modal */}
      <NewTransactionModal
        isOpen={isNewTxnOpen}
        onClose={() => setIsNewTxnOpen(false)}
        onCreate={handleCreateTransaction}
      />

      {/* Global Command Palette (⌘K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectTab={setCurrentTab}
        onOpenNewTransaction={() => setIsNewTxnOpen(true)}
        onExportCSV={() => handleExportCSV()}
        onToggleTheme={() => setIsDark((prev) => !prev)}
        isDark={isDark}
        transactions={transactions}
        onSelectTransaction={setSelectedTxn}
      />

      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
