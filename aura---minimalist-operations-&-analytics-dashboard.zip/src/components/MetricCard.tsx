import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { MetricSummary } from '../types/dashboard';

interface MetricCardProps {
  metric: MetricSummary;
}

export const MetricCard: React.FC<MetricCardProps> = ({ metric }) => {
  // Generate simple SVG path from sparkline points
  const points = metric.sparkline;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const width = 100;
  const height = 32;

  const pathCoordinates = points.map((val, index) => {
    const x = (index / (points.length - 1)) * width;
    const y = height - ((val - min) / range) * (height - 6) - 3;
    return `${x},${y}`;
  });

  const svgPath = `M ${pathCoordinates.join(' L ')}`;

  return (
    <div className="p-4 sm:p-5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 transition-all flex flex-col justify-between">
      <div className="flex items-start justify-between gap-2">
        <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
          {metric.title}
        </span>
        <div className="w-20 h-7 shrink-0">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full h-full overflow-visible"
            aria-hidden="true"
          >
            <path
              d={svgPath}
              fill="none"
              stroke="currentColor"
              strokeWidth="1.75"
              strokeLinecap="round"
              strokeLinejoin="round"
              className={
                metric.isPositive
                  ? 'text-emerald-500/80 dark:text-emerald-400/80'
                  : 'text-neutral-400 dark:text-neutral-500'
              }
            />
          </svg>
        </div>
      </div>

      <div className="mt-3">
        <div className="text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900 dark:text-neutral-100 font-mono tabular-nums">
          {metric.value}
        </div>

        {/* Unboxed clean metadata with typographic separator */}
        <div className="flex items-center gap-1.5 mt-1.5 text-xs text-neutral-500 dark:text-neutral-400">
          <span
            className={`inline-flex items-center font-mono tabular-nums font-medium ${
              metric.isPositive
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-neutral-600 dark:text-neutral-400'
            }`}
          >
            {metric.isPositive ? (
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5 inline shrink-0" />
            ) : (
              <ArrowDownRight className="w-3.5 h-3.5 mr-0.5 inline shrink-0" />
            )}
            {metric.change}
          </span>
          <span className="text-neutral-300 dark:text-neutral-600" aria-hidden="true">
            ·
          </span>
          <span className="truncate">{metric.timeframeText}</span>
        </div>
      </div>
    </div>
  );
};
