import React from 'react';
import {
  Search,
  Command,
  Receipt,
  Users,
  Wallet,
  Settings,
  Activity,
  Plus,
  Moon,
  Sun,
  Download,
  Terminal,
  ArrowRight,
} from 'lucide-react';
import { NavTab } from './Sidebar';
import { Transaction } from '../types/dashboard';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: NavTab) => void;
  onOpenNewTransaction: () => void;
  onExportCSV: () => void;
  onToggleTheme: () => void;
  isDark: boolean;
  transactions: Transaction[];
  onSelectTransaction: (txn: Transaction) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onOpenNewTransaction,
  onExportCSV,
  onToggleTheme,
  isDark,
  transactions,
  onSelectTransaction,
}) => {
  const [query, setQuery] = React.useState('');

  if (!isOpen) return null;

  const quickNav = [
    { label: 'Go to Overview Dashboard', tab: 'overview' as NavTab, icon: Activity },
    { label: 'Go to Transactions Ledger', tab: 'ledger' as NavTab, icon: Receipt },
    { label: 'Go to Counterparty Directory', tab: 'customers' as NavTab, icon: Users },
    { label: 'Go to Settlements & Treasury', tab: 'payouts' as NavTab, icon: Wallet },
    { label: 'Go to Webhooks & Developer Hub', tab: 'webhooks' as NavTab, icon: Terminal },
    { label: 'Go to Security & Preferences', tab: 'settings' as NavTab, icon: Settings },
  ];

  const filteredNav = quickNav.filter((n) =>
    n.label.toLowerCase().includes(query.toLowerCase())
  );

  const matchedTxns = query.trim().length > 1
    ? transactions
        .filter(
          (t) =>
            t.id.toLowerCase().includes(query.toLowerCase()) ||
            t.customer.name.toLowerCase().includes(query.toLowerCase()) ||
            t.customer.email.toLowerCase().includes(query.toLowerCase())
        )
        .slice(0, 5)
    : [];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-neutral-950/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="flex min-h-full items-start justify-center p-4 pt-16 sm:pt-24">
        <div className="relative w-full max-w-xl bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/90 dark:border-neutral-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          {/* Search Input Bar */}
          <div className="flex items-center px-4 py-3.5 border-b border-neutral-200/80 dark:border-neutral-800 gap-3">
            <Search className="w-4 h-4 text-neutral-400 shrink-0" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type a command, search transaction ID, or jump to workspace..."
              className="w-full bg-transparent text-sm text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-hidden"
            />
            <kbd className="px-1.5 py-0.5 text-[10px] font-mono text-neutral-400 dark:text-neutral-500 bg-neutral-100 dark:bg-neutral-800 rounded border border-neutral-200 dark:border-neutral-700">
              ESC
            </kbd>
          </div>

          {/* Quick Actions List */}
          <div className="max-h-96 overflow-y-auto p-2 space-y-4 text-xs">
            {/* Direct Actions */}
            <div>
              <p className="px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-neutral-400">
                Quick Actions
              </p>
              <div className="space-y-0.5">
                <button
                  onClick={() => {
                    onOpenNewTransaction();
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <Plus className="w-3.5 h-3.5 text-neutral-500" />
                    <span>Record New Charge / Transaction</span>
                  </div>
                  <span className="text-[11px] text-neutral-400 font-mono">N</span>
                </button>

                <button
                  onClick={() => {
                    onExportCSV();
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <Download className="w-3.5 h-3.5 text-neutral-500" />
                    <span>Export Active Transactions CSV</span>
                  </div>
                  <span className="text-[11px] text-neutral-400 font-mono">⌘E</span>
                </button>

                <button
                  onClick={() => {
                    onToggleTheme();
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors text-left"
                >
                  <div className="flex items-center gap-2.5">
                    {isDark ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-neutral-500" />}
                    <span>Toggle Visual Theme ({isDark ? 'Light' : 'Dark'})</span>
                  </div>
                  <span className="text-[11px] text-neutral-400 font-mono">⌘T</span>
                </button>
              </div>
            </div>

            {/* Matching Transactions if query */}
            {matchedTxns.length > 0 && (
              <div>
                <p className="px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-neutral-400">
                  Transactions ({matchedTxns.length})
                </p>
                <div className="space-y-0.5">
                  {matchedTxns.map((txn) => (
                    <button
                      key={txn.id}
                      onClick={() => {
                        onSelectTransaction(txn);
                        onClose();
                      }}
                      className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 transition-colors text-left"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Receipt className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        <span className="font-mono font-medium truncate">{txn.id}</span>
                        <span className="text-neutral-400 truncate">· {txn.customer.name}</span>
                      </div>
                      <div className="font-mono text-neutral-900 dark:text-neutral-100 font-semibold shrink-0 ml-2">
                        {txn.currency === 'USD' ? '$' : txn.currency === 'EUR' ? '€' : '£'}
                        {txn.amount.toLocaleString()}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Navigation Workspaces */}
            <div>
              <p className="px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-neutral-400">
                Navigation
              </p>
              <div className="space-y-0.5">
                {filteredNav.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.tab}
                      onClick={() => {
                        onSelectTab(item.tab);
                        onClose();
                      }}
                      className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors text-left"
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{item.label}</span>
                      </div>
                      <ArrowRight className="w-3 h-3 text-neutral-400" />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Palette Footer */}
          <div className="px-4 py-2.5 bg-neutral-50 dark:bg-neutral-800/50 border-t border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400 font-mono">
            <div className="flex items-center gap-3">
              <span>↑↓ to navigate</span>
              <span>↵ to select</span>
            </div>
            <span>Aura Command Engine</span>
          </div>
        </div>
      </div>
    </div>
  );
};
