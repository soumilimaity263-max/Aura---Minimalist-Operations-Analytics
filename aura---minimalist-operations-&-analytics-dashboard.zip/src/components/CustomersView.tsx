import React, { useState } from 'react';
import { CUSTOMER_PROFILES } from '../data/mockData';
import {
  Search,
  Mail,
  ExternalLink,
  ShieldCheck,
  ArrowUpRight,
  X,
  CreditCard,
  Building2,
  Calendar,
  Globe,
  Receipt,
  Download,
} from 'lucide-react';
import { CustomerProfile, Transaction } from '../types/dashboard';

interface CustomersViewProps {
  transactions: Transaction[];
  onSelectTransaction: (txn: Transaction) => void;
  onShowToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning') => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  transactions,
  onSelectTransaction,
  onShowToast,
}) => {
  const [search, setSearch] = useState('');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [activeCustomer, setActiveCustomer] = useState<CustomerProfile | null>(null);

  const filtered = CUSTOMER_PROFILES.filter((c) => {
    const matchTier = selectedTier === 'all' || c.tier === selectedTier;
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      c.name.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      c.id.toLowerCase().includes(q);
    return matchTier && matchSearch;
  });

  const getCustomerTransactions = (customerEmail: string) => {
    return transactions.filter(
      (t) => t.customer.email.toLowerCase() === customerEmail.toLowerCase()
    );
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">Total Accounts</span>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1 tabular-nums">
            1,429
          </div>
          <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1 font-mono">
            <ArrowUpRight className="w-3.5 h-3.5" />
            +18.4% YoY Growth
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">Net Retention (NRR)</span>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1 tabular-nums">
            124.6%
          </div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Top decile SaaS cohort
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">Average Contract Value</span>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1 tabular-nums">
            $24,800
          </div>
          <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1 font-mono">
            <ArrowUpRight className="w-3.5 h-3.5" />
            +$3.2k expansion
          </div>
        </div>
      </div>

      {/* Directory Table */}
      <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden">
        {/* Table Filter Toolbar */}
        <div className="p-4 border-b border-neutral-200/80 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="relative min-w-[220px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search customers..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
              />
            </div>

            <div className="flex items-center gap-1 p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded-lg border border-neutral-200/60 dark:border-neutral-700/60 text-xs">
              {['all', 'Enterprise', 'Professional', 'Starter'].map((tier) => (
                <button
                  key={tier}
                  onClick={() => setSelectedTier(tier)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                    selectedTier === tier
                      ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                  }`}
                >
                  {tier === 'all' ? 'All Tiers' : tier}
                </button>
              ))}
            </div>
          </div>

          <div className="text-xs text-neutral-500 font-mono">
            {filtered.length} enterprise counterparties listed
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-200/80 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-800/40 text-neutral-500">
                <th className="px-4 py-3 font-medium">Customer / Organization</th>
                <th className="px-4 py-3 font-medium">Plan Tier</th>
                <th className="px-4 py-3 font-medium">Account State</th>
                <th className="px-4 py-3 font-medium">Region</th>
                <th className="px-4 py-3 font-medium text-right">Lifetime Spend</th>
                <th className="px-4 py-3 font-medium text-right">Last Settled</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200/60 dark:divide-neutral-800/60">
              {filtered.map((cust) => (
                <tr
                  key={cust.id}
                  onClick={() => setActiveCustomer(cust)}
                  className="hover:bg-neutral-50 dark:hover:bg-neutral-800/50 cursor-pointer transition-colors"
                >
                  <td className="px-4 py-3.5">
                    <div className="font-semibold text-neutral-900 dark:text-neutral-100">
                      {cust.name}
                    </div>
                    <div className="text-[11px] text-neutral-400 font-mono">{cust.email}</div>
                  </td>

                  <td className="px-4 py-3.5 text-neutral-800 dark:text-neutral-200 font-medium">
                    {cust.tier}
                  </td>

                  <td className="px-4 py-3.5">
                    <span className="inline-flex items-center gap-1.5 font-medium">
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          cust.status === 'Active'
                            ? 'bg-emerald-500'
                            : cust.status === 'At Risk'
                            ? 'bg-amber-500'
                            : 'bg-neutral-400'
                        }`}
                      />
                      <span
                        className={
                          cust.status === 'Active'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : cust.status === 'At Risk'
                            ? 'text-amber-700 dark:text-amber-400'
                            : 'text-neutral-500'
                        }
                      >
                        {cust.status}
                      </span>
                    </span>
                  </td>

                  <td className="px-4 py-3.5 text-neutral-500 dark:text-neutral-400">
                    {cust.region}
                  </td>

                  <td className="px-4 py-3.5 text-right font-mono font-semibold text-neutral-900 dark:text-neutral-100 tabular-nums">
                    ${cust.totalSpent.toLocaleString()}
                  </td>

                  <td className="px-4 py-3.5 text-right font-mono text-neutral-500 tabular-nums">
                    {cust.lastPayment}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Detail Slide-Over Drawer */}
      {activeCustomer && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div
            className="fixed inset-0 bg-neutral-950/40 backdrop-blur-xs transition-opacity"
            onClick={() => setActiveCustomer(null)}
            aria-hidden="true"
          />

          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-white dark:bg-neutral-900 border-l border-neutral-200/80 dark:border-neutral-800 shadow-xl flex flex-col">
              {/* Drawer Header */}
              <div className="p-5 border-b border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider">
                    Counterparty Profile
                  </span>
                  <h3 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 mt-0.5">
                    {activeCustomer.name}
                  </h3>
                </div>
                <button
                  onClick={() => setActiveCustomer(null)}
                  className="p-1.5 text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="flex-1 p-5 overflow-y-auto space-y-6 text-xs">
                {/* Account KPI Banner */}
                <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/70 dark:border-neutral-700/60 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-neutral-400">Total Lifetime Remittance</span>
                    <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
                      ${activeCustomer.totalSpent.toLocaleString()}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] text-neutral-400">Subscription Tier</span>
                    <div className="text-sm font-semibold text-neutral-900 dark:text-neutral-100 mt-0.5">
                      {activeCustomer.tier}
                    </div>
                  </div>
                </div>

                {/* Account details */}
                <div>
                  <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                    Contract & Account Specs
                  </h4>
                  <div className="p-3.5 rounded-lg border border-neutral-200/80 dark:border-neutral-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">Internal Reference</span>
                      <span className="font-mono text-neutral-800 dark:text-neutral-200">
                        {activeCustomer.id}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">Billing Email</span>
                      <span className="font-mono text-neutral-800 dark:text-neutral-200">
                        {activeCustomer.email}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">Customer Since</span>
                      <span className="font-mono text-neutral-800 dark:text-neutral-200">
                        {activeCustomer.joinedDate}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">Jurisdiction</span>
                      <span className="font-mono text-neutral-800 dark:text-neutral-200">
                        {activeCustomer.region}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Associated Transactions */}
                <div>
                  <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                    Associated Settlement Records
                  </h4>
                  <div className="space-y-2">
                    {getCustomerTransactions(activeCustomer.email).length === 0 ? (
                      <div className="p-3 rounded-lg border border-neutral-200/80 dark:border-neutral-800 text-neutral-400 text-center">
                        No transactions recorded in current cache
                      </div>
                    ) : (
                      getCustomerTransactions(activeCustomer.email).map((txn) => (
                        <div
                          key={txn.id}
                          onClick={() => {
                            setActiveCustomer(null);
                            onSelectTransaction(txn);
                          }}
                          className="p-3 rounded-lg border border-neutral-200/80 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 cursor-pointer flex items-center justify-between transition-colors"
                        >
                          <div>
                            <div className="font-mono font-medium text-neutral-900 dark:text-neutral-100">
                              {txn.id}
                            </div>
                            <div className="text-[11px] text-neutral-400 font-mono">
                              {txn.date}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-mono font-semibold text-neutral-900 dark:text-neutral-100">
                              {txn.currency === 'USD' ? '$' : '€'}
                              {txn.amount.toLocaleString()}
                            </div>
                            <span className="text-[10px] text-emerald-600 font-medium">
                              {txn.status.toUpperCase()}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Drawer Footer */}
              <div className="p-4 border-t border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
                <button
                  onClick={() => {
                    onShowToast(
                      'Statement Generated',
                      `Annual billing statement dispatched to ${activeCustomer.email}`,
                      'success'
                    );
                  }}
                  className="w-full py-2 px-3 text-xs font-medium bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg hover:bg-neutral-800 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Send Statement to Accounting</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
