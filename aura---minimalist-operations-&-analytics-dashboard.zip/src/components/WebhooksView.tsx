import React, { useState } from 'react';
import {
  Terminal,
  Send,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  Copy,
  Clock,
  ExternalLink,
  Code,
  Filter,
} from 'lucide-react';
import { WebhookLog, WebhookStatus } from '../types/dashboard';

interface WebhooksViewProps {
  webhooks: WebhookLog[];
  onTriggerTestWebhook: (event: string) => void;
  onRetryWebhook: (id: string) => void;
  onShowToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning') => void;
}

export const WebhooksView: React.FC<WebhooksViewProps> = ({
  webhooks,
  onTriggerTestWebhook,
  onRetryWebhook,
  onShowToast,
}) => {
  const [selectedEvent, setSelectedEvent] = useState<string>('payment.settled');
  const [selectedLog, setSelectedLog] = useState<WebhookLog | null>(webhooks[0] || null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'success' | 'failed'>('all');

  const filteredLogs = webhooks.filter((log) => {
    if (filterStatus === 'success') return log.statusCode >= 200 && log.statusCode < 300;
    if (filterStatus === 'failed') return log.statusCode >= 400;
    return true;
  });

  const handleCopyPayload = (payload: string) => {
    navigator.clipboard?.writeText(payload);
    onShowToast('Copied', 'JSON payload copied to clipboard.', 'info');
  };

  return (
    <div className="space-y-6 text-xs">
      {/* Test Event Dispatcher Console */}
      <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-100 dark:border-neutral-800/80">
          <div>
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-neutral-400" />
              <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                Webhook Simulator & Dispatch Sandbox
              </h3>
            </div>
            <p className="text-neutral-500 dark:text-neutral-400 mt-0.5">
              Simulate production HTTP POST notifications to test counterparty receiver resiliency.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedEvent}
              onChange={(e) => setSelectedEvent(e.target.value)}
              className="px-3 py-1.5 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 font-mono text-xs focus:outline-hidden"
            >
              <option value="payment.settled">payment.settled</option>
              <option value="payment.failed">payment.failed</option>
              <option value="payout.disbursed">payout.disbursed</option>
              <option value="subscription.renewed">subscription.renewed</option>
            </select>

            <button
              onClick={() => onTriggerTestWebhook(selectedEvent)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 font-medium rounded-lg hover:bg-neutral-800 dark:hover:bg-neutral-200 transition-colors shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Dispatch Test Event</span>
            </button>
          </div>
        </div>

        {/* Live Delivery Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/50">
            <span className="text-[11px] text-neutral-400">Total Dispatched</span>
            <div className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
              1,842
            </div>
          </div>
          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/50">
            <span className="text-[11px] text-neutral-400">Delivery Success</span>
            <div className="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
              99.78%
            </div>
          </div>
          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/50">
            <span className="text-[11px] text-neutral-400">Avg Round-Trip</span>
            <div className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
              42ms
            </div>
          </div>
          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/50">
            <span className="text-[11px] text-neutral-400">Dead-Letter Queue</span>
            <div className="text-lg font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
              0 payloads
            </div>
          </div>
        </div>
      </div>

      {/* Two-Pane Log Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Pane: Dispatch Logs List */}
        <div className="lg:col-span-7 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden">
          <div className="p-3.5 border-b border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
            <div className="font-semibold text-neutral-900 dark:text-neutral-100">
              Delivery Audit Logs
            </div>
            <div className="flex items-center gap-1 p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded-md text-[11px]">
              {(['all', 'success', 'failed'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setFilterStatus(filter)}
                  className={`px-2 py-0.5 rounded capitalize font-medium transition-all ${
                    filterStatus === filter
                      ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs'
                      : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-neutral-100 dark:divide-neutral-800/80 max-h-[500px] overflow-y-auto">
            {filteredLogs.map((log) => {
              const isSuccess = log.statusCode >= 200 && log.statusCode < 300;
              const isSelected = selectedLog?.id === log.id;

              return (
                <div
                  key={log.id}
                  onClick={() => setSelectedLog(log)}
                  className={`p-3.5 cursor-pointer transition-colors flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-neutral-100/80 dark:bg-neutral-800/80'
                      : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/40'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`font-mono text-[11px] font-semibold px-1.5 py-0.5 rounded ${
                        isSuccess
                          ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                          : 'bg-rose-500/10 text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      {log.statusCode}
                    </span>
                    <div className="min-w-0">
                      <div className="font-mono font-medium text-neutral-900 dark:text-neutral-100 truncate">
                        {log.event}
                      </div>
                      <div className="text-[11px] text-neutral-400 truncate max-w-xs font-mono">
                        {log.url}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono text-[11px] text-neutral-500">
                      {log.durationMs}ms
                    </div>
                    <div className="text-[10px] text-neutral-400">{log.timestamp}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Pane: Selected Payload Details */}
        <div className="lg:col-span-5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-4 space-y-4">
          {selectedLog ? (
            <>
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
                <div>
                  <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider">
                    Log Inspection
                  </span>
                  <h4 className="text-sm font-semibold font-mono text-neutral-900 dark:text-neutral-100">
                    {selectedLog.id}
                  </h4>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onRetryWebhook(selectedLog.id)}
                    className="px-2.5 py-1 text-xs border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md transition-colors flex items-center gap-1 text-neutral-700 dark:text-neutral-300"
                  >
                    <RotateCw className="w-3 h-3" />
                    <span>Re-deliver</span>
                  </button>
                  <button
                    onClick={() => handleCopyPayload(selectedLog.payloadSummary)}
                    className="p-1.5 border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md text-neutral-500"
                    title="Copy payload"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Delivery metadata */}
              <div className="space-y-2 text-[11px]">
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800/60">
                  <span className="text-neutral-400">Target Endpoint</span>
                  <span className="font-mono text-neutral-800 dark:text-neutral-200 truncate max-w-[200px]">
                    {selectedLog.url}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800/60">
                  <span className="text-neutral-400">HTTP Status</span>
                  <span
                    className={`font-mono font-semibold ${
                      selectedLog.statusCode < 300 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {selectedLog.statusCode}{' '}
                    {selectedLog.statusCode === 200
                      ? 'OK'
                      : selectedLog.statusCode === 429
                      ? 'Rate Limited'
                      : 'Error'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800/60">
                  <span className="text-neutral-400">Transit Duration</span>
                  <span className="font-mono text-neutral-800 dark:text-neutral-200">
                    {selectedLog.durationMs}ms
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800/60">
                  <span className="text-neutral-400">Transmission Attempts</span>
                  <span className="font-mono text-neutral-800 dark:text-neutral-200">
                    {selectedLog.attempts}
                  </span>
                </div>
              </div>

              {/* JSON Payload Display */}
              <div>
                <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider block mb-1.5">
                  Decrypted JSON Payload Body
                </span>
                <pre className="p-3 rounded-lg bg-neutral-950 text-neutral-100 font-mono text-[11px] overflow-x-auto leading-relaxed border border-neutral-800 select-all">
                  {JSON.stringify(JSON.parse(selectedLog.payloadSummary), null, 2)}
                </pre>
              </div>
            </>
          ) : (
            <div className="text-center py-12 text-neutral-400">
              Select a delivery log on the left to inspect its payload details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
