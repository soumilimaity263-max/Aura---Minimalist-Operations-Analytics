import React from 'react';
import {
  X,
  Copy,
  Download,
  RotateCcw,
  CheckCircle2,
  Clock,
  AlertCircle,
  Building2,
  Mail,
  Globe,
  CreditCard,
  FileText,
} from 'lucide-react';
import { Transaction } from '../types/dashboard';

interface TransactionDrawerProps {
  transaction: Transaction | null;
  onClose: () => void;
  onRefund: (id: string) => void;
  onShowToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning') => void;
}

export const TransactionDrawer: React.FC<TransactionDrawerProps> = ({
  transaction,
  onClose,
  onRefund,
  onShowToast,
}) => {
  if (!transaction) return null;

  const handleCopyId = () => {
    navigator.clipboard?.writeText(transaction.id);
    onShowToast('Copied to Clipboard', `Reference ${transaction.id} copied.`, 'info');
  };

  const handleDownloadReceipt = () => {
    const content = `================================================
AURA CLOUD TECHNOLOGIES - OFFICIAL SETTLEMENT RECEIPT
================================================
Transaction ID : ${transaction.id}
Date & Time    : ${transaction.date} UTC
Account        : ${transaction.customer.name} (${transaction.customer.email})
Plan           : ${transaction.plan}
Region         : ${transaction.region}
Payment Method : ${transaction.paymentMethod}
Status         : ${transaction.status.toUpperCase()}

------------------------------------------------
FINANCIAL BREAKDOWN:
Gross Processed  : ${transaction.currency} ${transaction.amount.toFixed(2)}
Processing Fees  : -${transaction.currency} ${transaction.fees.toFixed(2)}
Net Remittance   : ${transaction.currency} ${(transaction.amount - transaction.fees).toFixed(2)}
------------------------------------------------
Security Hash   : 0x9f81a7b8e21c32454a8b792
Reconciliation  : APPROVED & SIGNED
================================================`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `receipt-${transaction.id}.txt`;
    link.click();
    URL.revokeObjectURL(url);

    onShowToast('Receipt Downloaded', `Receipt saved for ${transaction.id}`, 'success');
  };

  const symbol = transaction.currency === 'USD' ? '$' : transaction.currency === 'EUR' ? '€' : '£';

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-neutral-950/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-neutral-900 border-l border-neutral-200/80 dark:border-neutral-800 shadow-xl flex flex-col">
          {/* Drawer Header */}
          <div className="p-5 border-b border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">
                Transaction Inspector
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <h3 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 font-mono">
                  {transaction.id}
                </h3>
                <button
                  onClick={handleCopyId}
                  className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded"
                  title="Copy ID"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 rounded-lg"
              aria-label="Close details"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Content */}
          <div className="flex-1 p-5 overflow-y-auto space-y-6 text-xs">
            {/* Primary Amount Banner */}
            <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200/70 dark:border-neutral-700/60 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                  Gross Processed
                </span>
                <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-0.5">
                  {symbol}
                  {transaction.amount.toLocaleString()}
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                  Status
                </span>
                <div className="mt-1">
                  {transaction.status === 'settled' ? (
                    <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Settled
                    </span>
                  ) : transaction.status === 'processing' ? (
                    <span className="inline-flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-medium">
                      <Clock className="w-3.5 h-3.5" />
                      In Escrow
                    </span>
                  ) : transaction.status === 'refunded' ? (
                    <span className="inline-flex items-center gap-1.5 text-neutral-500 font-medium">
                      <RotateCcw className="w-3.5 h-3.5" />
                      Refunded
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 text-rose-600 font-medium">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Failed
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Lifecycle Timeline */}
            <div>
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-3">
                Audit Trail
              </h4>
              <div className="relative pl-5 space-y-4 border-l border-neutral-200 dark:border-neutral-800 ml-1">
                <div className="relative">
                  <div className="absolute -left-[25px] top-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-4 ring-white dark:ring-neutral-900" />
                  <p className="font-medium text-neutral-900 dark:text-neutral-100">
                    Payment Gateway Handshake
                  </p>
                  <p className="text-neutral-400 font-mono text-[11px] mt-0.5">
                    {transaction.date} · Latency 38ms
                  </p>
                </div>

                <div className="relative">
                  <div className="absolute -left-[25px] top-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-4 ring-white dark:ring-neutral-900" />
                  <p className="font-medium text-neutral-900 dark:text-neutral-100">
                    3D Secure Authentication Passed
                  </p>
                  <p className="text-neutral-400 font-mono text-[11px] mt-0.5">
                    Card verified with {transaction.paymentMethod}
                  </p>
                </div>

                <div className="relative">
                  <div
                    className={`absolute -left-[25px] top-0.5 w-2.5 h-2.5 rounded-full ring-4 ring-white dark:ring-neutral-900 ${
                      transaction.status === 'settled'
                        ? 'bg-emerald-500'
                        : transaction.status === 'refunded'
                        ? 'bg-neutral-400'
                        : 'bg-amber-500'
                    }`}
                  />
                  <p className="font-medium text-neutral-900 dark:text-neutral-100">
                    {transaction.status === 'settled'
                      ? 'Funds Cleared to Primary Escrow'
                      : transaction.status === 'refunded'
                      ? 'Reversal Processed to Original Instrument'
                      : 'Pending Batch Settlement Window'}
                  </p>
                  <p className="text-neutral-400 font-mono text-[11px] mt-0.5">
                    Region: {transaction.region}
                  </p>
                </div>
              </div>
            </div>

            {/* Customer Information */}
            <div>
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-2">
                Counterparty Details
              </h4>
              <div className="p-3.5 rounded-lg border border-neutral-200/80 dark:border-neutral-800 space-y-2.5">
                <div className="flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-neutral-400" />
                  <span className="font-medium text-neutral-900 dark:text-neutral-100">
                    {transaction.customer.name}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                  <Mail className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{transaction.customer.email}</span>
                </div>
                <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                  <Globe className="w-3.5 h-3.5 text-neutral-400" />
                  <span>Routed via {transaction.region}</span>
                </div>
                <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                  <CreditCard className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{transaction.paymentMethod}</span>
                </div>
              </div>
            </div>

            {/* Financial Ledger Math */}
            <div>
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 mb-2">
                Settlement Math
              </h4>
              <div className="p-3.5 rounded-lg border border-neutral-200/80 dark:border-neutral-800 space-y-2 font-mono">
                <div className="flex justify-between">
                  <span className="text-neutral-500 font-sans">Gross Transaction</span>
                  <span className="tabular-nums">
                    {symbol}
                    {transaction.amount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 font-sans">Gateway Fee (Est. 1%)</span>
                  <span className="tabular-nums text-neutral-500">
                    -{symbol}
                    {transaction.fees.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-neutral-200 dark:border-neutral-800 font-semibold text-neutral-900 dark:text-neutral-100">
                  <span className="font-sans">Net Payout to Account</span>
                  <span className="tabular-nums text-emerald-600 dark:text-emerald-400">
                    {symbol}
                    {(transaction.amount - transaction.fees).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Drawer Actions Footer */}
          <div className="p-4 border-t border-neutral-200/80 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-800/20 flex items-center justify-between gap-2">
            <button
              onClick={handleDownloadReceipt}
              className="flex-1 py-2 px-3 text-xs font-medium border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Download Receipt</span>
            </button>

            {transaction.status === 'settled' && (
              <button
                onClick={() => {
                  onRefund(transaction.id);
                  onClose();
                }}
                className="py-2 px-3 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 border border-rose-200 dark:border-rose-900/50 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Issue Refund</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
