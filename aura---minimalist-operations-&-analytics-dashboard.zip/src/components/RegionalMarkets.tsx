import React from 'react';
import { REGIONAL_MARKETS } from '../data/mockData';
import { Globe2, ArrowUpRight, Cpu } from 'lucide-react';

export const RegionalMarkets: React.FC = () => {
  return (
    <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-5 transition-all">
      <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800/80">
        <div>
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            Regional Distribution & Latency
          </h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Cross-border settlement share and edge node gateway performance.
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-neutral-500">
          <Globe2 className="w-3.5 h-3.5 text-neutral-400" />
          <span className="font-mono text-[11px]">4 Active Regions</span>
        </div>
      </div>

      <div className="mt-4 space-y-4">
        {REGIONAL_MARKETS.map((market) => (
          <div key={market.countryCode} className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="font-mono font-medium text-neutral-900 dark:text-neutral-100">
                  {market.countryCode}
                </span>
                <span className="text-neutral-500 dark:text-neutral-400 truncate max-w-[180px] sm:max-w-xs">
                  {market.region}
                </span>
              </div>

              <div className="flex items-center gap-3 font-mono tabular-nums">
                <span className="text-neutral-500 text-[11px] hidden sm:inline">
                  {market.latencyMs}ms edge
                </span>
                <span className="text-emerald-600 dark:text-emerald-400 text-xs">
                  {market.growth}
                </span>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100 w-12 text-right">
                  {market.share}%
                </span>
              </div>
            </div>

            {/* Custom minimalist progress bar */}
            <div className="h-1.5 w-full bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-neutral-900 dark:bg-neutral-100 rounded-full transition-all duration-500"
                style={{ width: `${market.share}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-500 dark:text-neutral-400 font-mono">
        <span className="flex items-center gap-1.5">
          <Cpu className="w-3.5 h-3.5 text-neutral-400" />
          Edge Routing: Fastly Anycast Global
        </span>
        <span>Avg global transit: 38ms</span>
      </div>
    </div>
  );
};
