import React from 'react';
import { AlertTriangle, AlertCircle, Info, CheckCircle2, ChevronRight, X, ShieldAlert } from 'lucide-react';
import { AnomalyAlert } from '../types/dashboard';

interface AnomalyBannerProps {
  anomalies: AnomalyAlert[];
  onDismiss: (id: string) => void;
  onResolve: (id: string) => void;
}

export const AnomalyBanner: React.FC<AnomalyBannerProps> = ({
  anomalies,
  onDismiss,
  onResolve,
}) => {
  const activeAnomalies = anomalies.filter((a) => !a.resolved);
  if (activeAnomalies.length === 0) return null;

  return (
    <div className="space-y-2">
      {activeAnomalies.map((item) => {
        const isCritical = item.severity === 'critical';
        const isWarning = item.severity === 'warning';

        return (
          <div
            key={item.id}
            className={`p-3.5 sm:p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
              isCritical
                ? 'bg-rose-500/5 border-rose-500/20 text-rose-950 dark:text-rose-100'
                : isWarning
                ? 'bg-amber-500/5 border-amber-500/20 text-amber-950 dark:text-amber-100'
                : 'bg-neutral-500/5 border-neutral-500/20 text-neutral-900 dark:text-neutral-100'
            }`}
          >
            <div className="flex items-start gap-3 min-w-0">
              <div className="mt-0.5 shrink-0">
                {isCritical ? (
                  <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                ) : isWarning ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                ) : (
                  <Info className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                )}
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold tracking-tight text-neutral-900 dark:text-white">
                    {item.title}
                  </span>
                  <span className="font-mono text-[10px] text-neutral-400 dark:text-neutral-500">
                    {item.timestamp}
                  </span>
                </div>
                <p className="text-neutral-600 dark:text-neutral-300 mt-0.5 leading-relaxed">
                  {item.detail}
                </p>
                {item.metric && (
                  <div className="mt-1 font-mono text-[11px] text-neutral-500 dark:text-neutral-400">
                    Telemetry: <span className="font-semibold text-neutral-800 dark:text-neutral-200">{item.metric}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
              {item.actionRequired && (
                <button
                  onClick={() => onResolve(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shadow-xs ${
                    isCritical
                      ? 'bg-rose-600 hover:bg-rose-700 text-white'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-neutral-100 dark:text-neutral-950'
                  }`}
                >
                  {item.actionRequired}
                </button>
              )}
              <button
                onClick={() => onDismiss(item.id)}
                className="p-1.5 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 rounded-md transition-colors"
                aria-label="Acknowledge alert"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
