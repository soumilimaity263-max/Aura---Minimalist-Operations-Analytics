import React, { useState, useId } from 'react';
import { ChartDataPoint, MetricType, TimePeriod } from '../types/dashboard';

interface RevenueChartProps {
  data: ChartDataPoint[];
  period: TimePeriod;
}

export const RevenueChart: React.FC<RevenueChartProps> = ({ data, period }) => {
  const [metricMode, setMetricMode] = useState<MetricType>('revenue');
  const [chartType, setChartType] = useState<'curve' | 'bar'>('curve');
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const gradientId = useId();

  if (!data || data.length === 0) return null;

  // Values based on active metric mode
  const values = data.map((d) => {
    if (metricMode === 'revenue') return d.revenue;
    if (metricMode === 'mrr') return d.mrr;
    return d.volume;
  });

  const baselineValues = data.map((d) => {
    if (metricMode === 'revenue') return d.previousRevenue;
    if (metricMode === 'mrr') return Math.round(d.mrr * 0.88);
    return Math.round(d.volume * 0.85);
  });

  const activeIndex = hoverIndex !== null ? hoverIndex : data.length - 1;
  const activePoint = data[activeIndex];
  const activeVal = values[activeIndex];
  const activePrev = baselineValues[activeIndex];
  const variance = activePrev ? (((activeVal - activePrev) / activePrev) * 100).toFixed(1) : '0';

  // SVG Drawing calculations
  const width = 800;
  const height = 260;
  const paddingX = 40;
  const paddingTop = 25;
  const paddingBottom = 35;

  const maxVal = Math.max(...values, ...baselineValues) * 1.15 || 100;
  const minVal = 0;
  const innerWidth = width - paddingX * 2;
  const innerHeight = height - paddingTop - paddingBottom;

  const getCoordinates = (vals: number[]) => {
    return vals.map((val, idx) => {
      const x = paddingX + (idx / (vals.length - 1)) * innerWidth;
      const y = paddingTop + innerHeight - ((val - minVal) / (maxVal - minVal)) * innerHeight;
      return { x, y };
    });
  };

  const coords = getCoordinates(values);
  const baselineCoords = getCoordinates(baselineValues);

  // Generate smooth SVG path
  const linePath = coords.reduce((acc, point, i, arr) => {
    if (i === 0) return `M ${point.x} ${point.y}`;
    const prev = arr[i - 1];
    const cpx1 = prev.x + (point.x - prev.x) / 3;
    const cpy1 = prev.y;
    const cpx2 = prev.x + ((point.x - prev.x) * 2) / 3;
    const cpy2 = point.y;
    return `${acc} C ${cpx1} ${cpy1}, ${cpx2} ${cpy2}, ${point.x} ${point.y}`;
  }, '');

  const areaPath = `${linePath} L ${coords[coords.length - 1].x} ${
    paddingTop + innerHeight
  } L ${coords[0].x} ${paddingTop + innerHeight} Z`;

  const baselinePath = baselineCoords.reduce((acc, point, i) => {
    return i === 0 ? `M ${point.x} ${point.y}` : `${acc} L ${point.x} ${point.y}`;
  }, '');

  const formatDisplay = (num: number) => {
    if (metricMode === 'volume') return num.toLocaleString();
    return `$${num.toLocaleString()}`;
  };

  // 4 Y-axis horizontal guideline values
  const yTicks = [0, 0.33, 0.66, 1].map((ratio) => {
    const val = Math.round(minVal + ratio * (maxVal - minVal));
    const y = paddingTop + innerHeight - ratio * innerHeight;
    return { val, y };
  });

  return (
    <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-5 transition-all">
      {/* Chart Top Row: Scrubber Stats & Mode Selectors */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-100 dark:border-neutral-800/80">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
              {metricMode === 'revenue'
                ? 'Gross Processed Revenue'
                : metricMode === 'mrr'
                ? 'Monthly Recurring Revenue'
                : 'Settled Transaction Volume'}
            </span>
            <span className="text-neutral-300 dark:text-neutral-600" aria-hidden="true">
              ·
            </span>
            <span className="text-xs text-neutral-400 dark:text-neutral-500 font-mono">
              {activePoint.date}
            </span>
          </div>

          <div className="flex items-baseline gap-3 mt-1">
            <span className="text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900 dark:text-neutral-100 font-mono tabular-nums">
              {formatDisplay(activeVal)}
            </span>
            <span className="text-xs font-mono tabular-nums text-neutral-500 dark:text-neutral-400">
              prev period:{' '}
              <span className="text-neutral-700 dark:text-neutral-300 font-medium">
                {formatDisplay(activePrev)}
              </span>{' '}
              <span className={Number(variance) >= 0 ? 'text-emerald-600' : 'text-rose-500'}>
                ({Number(variance) >= 0 ? `+${variance}%` : `${variance}%`})
              </span>
            </span>
          </div>
        </div>

        {/* Metric Mode Filter Tabs & Chart Type Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Chart Display Style */}
          <div className="flex items-center gap-1 p-0.5 bg-neutral-100 dark:bg-neutral-800/80 rounded-lg border border-neutral-200/60 dark:border-neutral-700/60 text-xs">
            <button
              onClick={() => setChartType('curve')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                chartType === 'curve'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
              }`}
            >
              Curve
            </button>
            <button
              onClick={() => setChartType('bar')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                chartType === 'bar'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs'
                  : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
              }`}
            >
              Bars
            </button>
          </div>

          <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800/80 rounded-lg border border-neutral-200/60 dark:border-neutral-700/60">
            <button
              onClick={() => setMetricMode('revenue')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                metricMode === 'revenue'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs font-semibold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
              }`}
            >
              Revenue
            </button>
            <button
              onClick={() => setMetricMode('mrr')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                metricMode === 'mrr'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs font-semibold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
              }`}
            >
              MRR
            </button>
            <button
              onClick={() => setMetricMode('volume')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                metricMode === 'volume'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs font-semibold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
              }`}
            >
              Volume
            </button>
          </div>
        </div>
      </div>

      {/* SVG Canvas Container */}
      <div className="relative mt-4 w-full h-64 sm:h-72 select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full overflow-visible"
          preserveAspectRatio="none"
          onMouseLeave={() => setHoverIndex(null)}
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = (e.clientX - rect.left) / rect.width;
            const targetX = relX * width;
            // find closest point index
            let closestIdx = 0;
            let minDist = Infinity;
            coords.forEach((c, idx) => {
              const dist = Math.abs(c.x - targetX);
              if (dist < minDist) {
                minDist = dist;
                closestIdx = idx;
              }
            });
            setHoverIndex(closestIdx);
          }}
        >
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="currentColor" stopOpacity="0.12" />
              <stop offset="100%" stopColor="currentColor" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Background horizontal guide lines */}
          {yTicks.map((tick, i) => (
            <g key={i}>
              <line
                x1={paddingX}
                y1={tick.y}
                x2={width - paddingX}
                y2={tick.y}
                stroke="currentColor"
                strokeDasharray="2 3"
                className="text-neutral-200/80 dark:text-neutral-800/80"
              />
              <text
                x={paddingX - 8}
                y={tick.y + 3}
                textAnchor="end"
                className="text-[10px] fill-neutral-400 dark:fill-neutral-500 font-mono tabular-nums"
              >
                {metricMode === 'volume'
                  ? tick.val.toLocaleString()
                  : `$${(tick.val / 1000).toFixed(0)}k`}
              </text>
            </g>
          ))}

          {/* If chartType is curve, render line and area */}
          {chartType === 'curve' ? (
            <>
              {/* Area fill */}
              <path
                d={areaPath}
                fill={`url(#${gradientId})`}
                className="text-neutral-900 dark:text-neutral-100"
              />

              {/* Baseline previous period line (subtle dashed) */}
              <path
                d={baselinePath}
                fill="none"
                stroke="currentColor"
                strokeWidth="1.2"
                strokeDasharray="4 4"
                className="text-neutral-300 dark:text-neutral-700"
              />

              {/* Current period smooth line */}
              <path
                d={linePath}
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                className="text-neutral-900 dark:text-neutral-100"
              />
            </>
          ) : (
            /* Bar mode rendering */
            <g>
              {coords.map((c, i) => {
                const barWidth = Math.min(32, innerWidth / coords.length - 8);
                const barHeight = paddingTop + innerHeight - c.y;
                const isHovered = i === activeIndex;

                return (
                  <rect
                    key={i}
                    x={c.x - barWidth / 2}
                    y={c.y}
                    width={barWidth}
                    height={barHeight}
                    rx="3"
                    className={`transition-colors ${
                      isHovered
                        ? 'fill-neutral-900 dark:fill-neutral-100'
                        : 'fill-neutral-300 dark:fill-neutral-700 hover:fill-neutral-600'
                    }`}
                  />
                );
              })}
            </g>
          )}

          {/* Interactive Scrubber Line & Dot */}
          {activeIndex !== null && coords[activeIndex] && (
            <g>
              <line
                x1={coords[activeIndex].x}
                y1={paddingTop}
                x2={coords[activeIndex].x}
                y2={paddingTop + innerHeight}
                stroke="currentColor"
                strokeWidth="1"
                strokeDasharray="3 3"
                className="text-neutral-500 dark:text-neutral-400"
              />
              {/* Dot on current line */}
              <circle
                cx={coords[activeIndex].x}
                cy={coords[activeIndex].y}
                r="4.5"
                className="fill-white dark:fill-neutral-900 stroke-neutral-900 dark:stroke-white"
                strokeWidth="2.5"
              />
              {/* Dot on baseline */}
              <circle
                cx={baselineCoords[activeIndex].x}
                cy={baselineCoords[activeIndex].y}
                r="3"
                className="fill-neutral-400 dark:fill-neutral-600"
              />
            </g>
          )}

          {/* X-axis date labels */}
          {coords.map((c, i) => (
            <text
              key={i}
              x={c.x}
              y={height - 8}
              textAnchor="middle"
              className={`text-[11px] font-mono select-none ${
                i === activeIndex
                  ? 'fill-neutral-900 dark:fill-neutral-100 font-semibold'
                  : 'fill-neutral-400 dark:fill-neutral-500'
              }`}
            >
              {data[i].date}
            </text>
          ))}
        </svg>
      </div>

      {/* Legend & Period Note */}
      <div className="flex items-center justify-between mt-2 pt-3 border-t border-neutral-100 dark:border-neutral-800/80 text-[11px] text-neutral-500 dark:text-neutral-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 rounded-full bg-neutral-900 dark:bg-neutral-100" />
            Current Period
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 rounded-full bg-neutral-400 dark:bg-neutral-600 border-dashed" />
            Prior Benchmark
          </span>
        </div>
        <span className="hidden sm:inline font-mono">Real-time gateway sync active</span>
      </div>
    </div>
  );
};
