import React, { useState } from 'react';
import { Copy, Check, Eye, EyeOff, Shield, KeyRound, BellRing, Sliders } from 'lucide-react';

interface SettingsViewProps {
  onShowToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning') => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onShowToast }) => {
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKeyCopied, setApiKeyCopied] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState('https://api.auracloud.io/v2/webhooks/incoming');
  const [defaultCurrency, setDefaultCurrency] = useState('USD');
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [twoFactor, setTwoFactor] = useState(true);

  const rawKey = 'aura_live_sec_9942a8b910e54cd3b77840921fb9';

  const handleCopyKey = () => {
    navigator.clipboard?.writeText(rawKey);
    setApiKeyCopied(true);
    onShowToast('API Key Copied', 'Production Secret Key placed in clipboard.', 'info');
    setTimeout(() => setApiKeyCopied(false), 2000);
  };

  const handleSaveWebhook = (e: React.FormEvent) => {
    e.preventDefault();
    onShowToast('Webhook Updated', `Dispatch endpoint saved to ${webhookUrl}`, 'success');
  };

  return (
    <div className="max-w-4xl space-y-8 text-xs">
      {/* API Authentication & Security */}
      <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-6 space-y-4">
        <div className="flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-neutral-400" />
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            API Credentials & Cryptographic Keys
          </h3>
        </div>
        <p className="text-neutral-500 dark:text-neutral-400 leading-relaxed">
          Production secret keys carry full administrative privileges across customer transactions and bank wire payouts. Keep these secret.
        </p>

        <div className="space-y-3">
          <div>
            <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Production Secret Key
            </label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  type={showApiKey ? 'text' : 'password'}
                  readOnly
                  value={rawKey}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 font-mono text-neutral-900 dark:text-neutral-100 text-xs"
                />
              </div>

              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="p-2 border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg text-neutral-600 dark:text-neutral-300"
                aria-label={showApiKey ? 'Hide secret key' : 'Show secret key'}
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={handleCopyKey}
                className="px-3 py-2 border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg text-neutral-700 dark:text-neutral-200 font-medium flex items-center gap-1.5"
              >
                {apiKeyCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{apiKeyCopied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Webhook Dispatch Target */}
      <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-6 space-y-4">
        <div className="flex items-center gap-2">
          <BellRing className="w-4 h-4 text-neutral-400" />
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            Real-Time Webhook Transit
          </h3>
        </div>
        <p className="text-neutral-500 dark:text-neutral-400">
          We dispatch signed HMAC-SHA256 payloads whenever transaction state transitions occur.
        </p>

        <form onSubmit={handleSaveWebhook} className="space-y-3">
          <div>
            <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Dispatch Destination URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="url"
                required
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                className="flex-1 px-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 font-mono text-xs text-neutral-900 dark:text-neutral-100"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-950 font-medium rounded-lg hover:bg-neutral-800 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Preferences & System Defaults */}
      <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-neutral-400" />
          <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
            Regional Currency & Compliance
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Base Reporting Currency
            </label>
            <select
              value={defaultCurrency}
              onChange={(e) => {
                setDefaultCurrency(e.target.value);
                onShowToast('Currency Updated', `Default display set to ${e.target.value}`, 'info');
              }}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100"
            >
              <option value="USD">USD - United States Dollar ($)</option>
              <option value="EUR">EUR - European Euro (€)</option>
              <option value="GBP">GBP - British Pound Sterling (£)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Accounting Timezone
            </label>
            <select
              defaultValue="UTC"
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100"
            >
              <option value="UTC">UTC (Universal Coordinated Time)</option>
              <option value="America/New_York">America / New York (EDT)</option>
              <option value="Europe/London">Europe / London (BST)</option>
              <option value="Asia/Tokyo">Asia / Tokyo (JST)</option>
            </select>
          </div>
        </div>

        <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-3">
          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="font-medium text-neutral-800 dark:text-neutral-200">
                Automated Settlement Wire Alerts
              </p>
              <p className="text-neutral-400 text-[11px]">
                Receive instant confirmation when ACH disbursements land in treasury.
              </p>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900"
            />
          </label>

          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="font-medium text-neutral-800 dark:text-neutral-200">
                Hardware Key & WebAuthn Enforcement
              </p>
              <p className="text-neutral-400 text-[11px]">
                Require YubiKey or TouchID for transactions exceeding $25,000.
              </p>
            </div>
            <input
              type="checkbox"
              checked={twoFactor}
              onChange={(e) => setTwoFactor(e.target.checked)}
              className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
