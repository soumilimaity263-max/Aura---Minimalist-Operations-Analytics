import React from 'react';
import { ArrowUpRight, Building2, CheckCircle2, Clock, ShieldCheck, ArrowDownRight, RefreshCw } from 'lucide-react';

interface PayoutsViewProps {
  onShowToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning') => void;
}

export const PayoutsView: React.FC<PayoutsViewProps> = ({ onShowToast }) => {
  const payouts = [
    {
      id: 'PO-2026-0925',
      date: 'Scheduled for Tomorrow, 09:00 UTC',
      amount: '$142,850.00',
      account: 'JPMorgan Chase ···· 4821',
      status: 'pending',
      batchCount: 42,
    },
    {
      id: 'PO-2026-0922',
      date: 'Sep 22, 2026 · 10:14 UTC',
      amount: '$218,400.00',
      account: 'JPMorgan Chase ···· 4821',
      status: 'completed',
      batchCount: 68,
    },
    {
      id: 'PO-2026-0915',
      date: 'Sep 15, 2026 · 09:30 UTC',
      amount: '$189,220.00',
      account: 'JPMorgan Chase ···· 4821',
      status: 'completed',
      batchCount: 57,
    },
    {
      id: 'PO-2026-0908',
      date: 'Sep 08, 2026 · 11:00 UTC',
      amount: '$164,100.00',
      account: 'JPMorgan Chase ···· 4821',
      status: 'completed',
      batchCount: 49,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Treasury Balances */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">Available for Payout</span>
          <div className="text-3xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1 tabular-nums">
            $142,850.00
          </div>
          <div className="text-xs text-neutral-500 mt-2 flex items-center justify-between">
            <span>Next automatic sweep</span>
            <span className="font-mono text-neutral-800 dark:text-neutral-200">Tomorrow 09:00 UTC</span>
          </div>
        </div>

        <div className="p-5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">Escrow Reserve Buffer (5%)</span>
          <div className="text-3xl font-bold font-mono text-neutral-900 dark:text-neutral-100 mt-1 tabular-nums">
            $32,400.00
          </div>
          <div className="text-xs text-neutral-500 mt-2 flex items-center justify-between">
            <span>Rolling 30-day risk escrow</span>
            <span className="text-emerald-600 font-mono">100% Funded</span>
          </div>
        </div>

        <div className="p-5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">Primary Operating Bank</span>
          <div className="text-lg font-semibold text-neutral-900 dark:text-neutral-100 mt-1 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-neutral-400" />
            <span>JPMorgan Chase Bank, N.A.</span>
          </div>
          <div className="text-xs text-neutral-500 font-mono mt-2">
            ACH Routing: 021000021 · Account: ····4821
          </div>
        </div>
      </div>

      {/* Payout History Ledger */}
      <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden">
        <div className="p-4 border-b border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              Settlement Disbursement Schedule
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Automated daily ACH wire sweeps to primary corporate treasury.
            </p>
          </div>

          <button
            onClick={() => onShowToast('Ledger Synced', 'Federal Reserve wire connection active.', 'info')}
            className="px-3 py-1.5 text-xs font-medium text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync Banking State</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-200/80 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-800/40 text-neutral-500">
                <th className="px-4 py-3 font-medium">Batch ID</th>
                <th className="px-4 py-3 font-medium">Disbursement Window</th>
                <th className="px-4 py-3 font-medium">Target Account</th>
                <th className="px-4 py-3 font-medium">Reconciled Transactions</th>
                <th className="px-4 py-3 font-medium text-right">Net Remittance</th>
                <th className="px-4 py-3 font-medium text-right">Settlement State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200/60 dark:divide-neutral-800/60">
              {payouts.map((p) => (
                <tr key={p.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors">
                  <td className="px-4 py-3.5 font-mono font-medium text-neutral-900 dark:text-neutral-100">
                    {p.id}
                  </td>
                  <td className="px-4 py-3.5 text-neutral-600 dark:text-neutral-300">
                    {p.date}
                  </td>
                  <td className="px-4 py-3.5 text-neutral-500 font-mono">
                    {p.account}
                  </td>
                  <td className="px-4 py-3.5 text-neutral-600 dark:text-neutral-300 font-mono tabular-nums">
                    {p.batchCount} entries aggregated
                  </td>
                  <td className="px-4 py-3.5 text-right font-mono font-semibold text-neutral-900 dark:text-neutral-100 text-sm tabular-nums">
                    {p.amount}
                  </td>
                  <td className="px-4 py-3.5 text-right">
                    {p.status === 'completed' ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Transferred
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-medium">
                        <Clock className="w-3.5 h-3.5" />
                        In Queue
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
