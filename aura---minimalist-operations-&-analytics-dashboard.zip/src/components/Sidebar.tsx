import React from 'react';
import {
  LayoutDashboard,
  Receipt,
  Users,
  Wallet,
  Settings,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  X,
  CreditCard,
  LogOut,
  Terminal,
} from 'lucide-react';
import { USER_PROFILE } from '../data/mockData';

export type NavTab = 'overview' | 'ledger' | 'customers' | 'payouts' | 'webhooks' | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    { id: 'overview' as NavTab, label: 'Overview', icon: LayoutDashboard },
    { id: 'ledger' as NavTab, label: 'Transactions', icon: Receipt },
    { id: 'customers' as NavTab, label: 'Customers', icon: Users },
    { id: 'payouts' as NavTab, label: 'Settlements', icon: Wallet },
    { id: 'webhooks' as NavTab, label: 'Webhooks & API', icon: Terminal },
    { id: 'settings' as NavTab, label: 'Preferences', icon: Settings },
  ];

  const handleSelect = (tab: NavTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-neutral-950/40 backdrop-blur-xs transition-opacity lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      {/* Main Sidebar Element */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col bg-white dark:bg-neutral-900 border-r border-neutral-200/80 dark:border-neutral-800 transition-all duration-200 ease-in-out lg:static ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } ${collapsed ? 'w-18' : 'w-64'}`}
      >
        {/* Brand Header */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-neutral-200/80 dark:border-neutral-800">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 flex items-center justify-center font-bold text-sm tracking-tighter shrink-0 select-none shadow-xs">
              A
            </div>
            {!collapsed && (
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-semibold tracking-tight text-neutral-900 dark:text-neutral-100 truncate">
                  Aura Operations
                </span>
                <span className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                  Production Hub
                </span>
              </div>
            )}
          </div>

          {/* Mobile close button */}
          <button
            onClick={onCloseMobile}
            className="p-1.5 text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100 lg:hidden rounded-md"
            aria-label="Close navigation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 py-4 px-2.5 space-y-1 overflow-y-auto">
          <div className="px-2 pb-2">
            {!collapsed && (
              <span className="text-[11px] font-medium uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
                Workspace
              </span>
            )}
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left relative group ${
                  isActive
                    ? 'bg-neutral-100 dark:bg-neutral-800 text-neutral-950 dark:text-neutral-50 font-semibold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-800/60 hover:text-neutral-900 dark:hover:text-neutral-200'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive
                      ? 'text-neutral-900 dark:text-neutral-100'
                      : 'text-neutral-500 dark:text-neutral-400 group-hover:text-neutral-800 dark:group-hover:text-neutral-200'
                  }`}
                />
                {!collapsed && <span className="truncate">{item.label}</span>}
                {isActive && (
                  <span className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-neutral-900 dark:bg-neutral-100" />
                )}
              </button>
            );
          })}
        </div>

        {/* Environment Status & User profile */}
        <div className="p-3 border-t border-neutral-200/80 dark:border-neutral-800 space-y-3">
          {!collapsed && (
            <div className="p-2.5 rounded-lg bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/60 dark:border-neutral-700/50">
              <div className="flex items-center justify-between text-[11px] text-neutral-500 dark:text-neutral-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Live Gateway
                </span>
                <span className="font-mono text-[10px] tabular-nums">99.98% SLA</span>
              </div>
            </div>
          )}

          {/* User profile row */}
          <div className="flex items-center gap-2.5 px-1">
            <div className="relative w-8 h-8 rounded-full overflow-hidden bg-neutral-200 dark:bg-neutral-700 shrink-0">
              <img
                src={USER_PROFILE.avatar}
                alt={USER_PROFILE.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
              <span className="absolute inset-0 flex items-center justify-center font-medium text-xs text-neutral-600 dark:text-neutral-300 pointer-events-none -z-10">
                ER
              </span>
            </div>

            {!collapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                  {USER_PROFILE.name}
                </p>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                  {USER_PROFILE.role}
                </p>
              </div>
            )}
          </div>

          {/* Desktop collapse toggle */}
          <div className="hidden lg:flex items-center justify-end pt-1">
            <button
              onClick={onToggleCollapse}
              className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-md transition-colors"
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
