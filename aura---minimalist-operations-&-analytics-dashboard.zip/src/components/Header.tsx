import React from 'react';
import { Menu, Search, Sun, Moon, Plus, Bell, Download } from 'lucide-react';
import { TimePeriod } from '../types/dashboard';
import { NavTab } from './Sidebar';

interface HeaderProps {
  currentTab: NavTab;
  period: TimePeriod;
  onPeriodChange: (period: TimePeriod) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenMobileNav: () => void;
  onOpenNewTransaction: () => void;
  onExportCurrentView: () => void;
  onOpenCommandPalette: () => void;
}

const TAB_TITLES: Record<NavTab, { root: string; sub: string }> = {
  overview: { root: 'Operations', sub: 'Overview' },
  ledger: { root: 'Financials', sub: 'Transactions' },
  customers: { root: 'Accounts', sub: 'Customer Directory' },
  payouts: { root: 'Treasury', sub: 'Settlement Ledger' },
  webhooks: { root: 'Developers', sub: 'Webhook Dispatch & Logs' },
  settings: { root: 'Platform', sub: 'Preferences' },
};

const PERIODS: { id: TimePeriod; label: string }[] = [
  { id: '24h', label: '24h' },
  { id: '7d', label: '7d' },
  { id: '30d', label: '30d' },
  { id: '90d', label: '90d' },
  { id: '12m', label: '12m' },
];

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  period,
  onPeriodChange,
  searchQuery,
  onSearchChange,
  isDark,
  onToggleTheme,
  onOpenMobileNav,
  onOpenNewTransaction,
  onExportCurrentView,
  onOpenCommandPalette,
}) => {
  const currentTitle = TAB_TITLES[currentTab];

  return (
    <header className="h-16 px-4 sm:px-6 bg-white dark:bg-neutral-900 border-b border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between gap-4 sticky top-0 z-30 transition-colors">
      {/* Zone 1: Breadcrumb Trail & Mobile Toggle */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onOpenMobileNav}
          className="p-1.5 -ml-1 text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-lg lg:hidden"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-1.5 text-xs">
          <span className="font-medium text-neutral-400 dark:text-neutral-500 hidden sm:inline">
            {currentTitle.root}
          </span>
          <span className="text-neutral-300 dark:text-neutral-600 hidden sm:inline">/</span>
          <span className="font-semibold text-neutral-900 dark:text-neutral-100 tracking-tight whitespace-nowrap">
            {currentTitle.sub}
          </span>
        </div>
      </div>

      {/* Zone 2: Global Search Field (Command Palette Trigger) */}
      <div className="flex-1 max-w-md hidden md:block">
        <button
          type="button"
          onClick={onOpenCommandPalette}
          className="w-full relative text-left flex items-center justify-between pl-9 pr-3 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800/80 text-neutral-400 dark:text-neutral-500 rounded-lg border border-neutral-200/80 dark:border-neutral-700/80 hover:border-neutral-300 dark:hover:border-neutral-600 transition-all cursor-pointer group"
        >
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 group-hover:text-neutral-600 dark:group-hover:text-neutral-300 pointer-events-none" />
          <span className="truncate group-hover:text-neutral-700 dark:group-hover:text-neutral-300">
            {searchQuery ? `Searching: ${searchQuery}` : 'Type a command, customer, or ID (⌘K)...'}
          </span>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-neutral-400 dark:text-neutral-500 bg-neutral-200/60 dark:bg-neutral-700/60 rounded shrink-0 ml-2">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Zone 3: Timeframe Controls, Theme Toggle & Primary Action */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Time Segmented Control (active on overview & ledger) */}
        {(currentTab === 'overview' || currentTab === 'ledger') && (
          <div className="hidden sm:flex items-center p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded-lg border border-neutral-200/60 dark:border-neutral-700/60">
            {PERIODS.map((item) => {
              const active = period === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onPeriodChange(item.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        )}

        {/* Quick Export Button */}
        <button
          onClick={onExportCurrentView}
          title="Export CSV dataset"
          className="p-2 text-neutral-600 hover:text-neutral-950 dark:text-neutral-400 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors"
          aria-label="Export dataset"
        >
          <Download className="w-4 h-4" />
        </button>

        {/* Theme Toggle */}
        <button
          onClick={onToggleTheme}
          title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          className="p-2 text-neutral-600 hover:text-neutral-950 dark:text-neutral-400 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors"
          aria-label="Toggle visual theme"
        >
          {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Primary CTA: New Transaction Entry */}
        <button
          onClick={onOpenNewTransaction}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 dark:text-neutral-950 dark:bg-neutral-100 dark:hover:bg-neutral-200 rounded-lg transition-colors shadow-xs whitespace-nowrap"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Entry</span>
        </button>
      </div>
    </header>
  );
};
