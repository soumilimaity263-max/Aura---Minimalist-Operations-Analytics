import React from 'react';
import { CheckCircle2, Info, AlertTriangle, X } from 'lucide-react';
import { ToastMessage } from '../types/dashboard';

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
      {toasts.map((toast) => {
        return (
          <div
            key={toast.id}
            role="status"
            className="pointer-events-auto flex items-start gap-3 p-3.5 bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-950 rounded-xl shadow-lg border border-neutral-800 dark:border-neutral-200 transition-all duration-200 animate-in fade-in slide-in-from-bottom-2"
          >
            <div className="mt-0.5 shrink-0">
              {toast.type === 'warning' ? (
                <AlertTriangle className="w-4 h-4 text-amber-400 dark:text-amber-600" />
              ) : toast.type === 'info' ? (
                <Info className="w-4 h-4 text-sky-400 dark:text-sky-600" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold tracking-tight">{toast.title}</p>
              {toast.description && (
                <p className="text-xs text-neutral-400 dark:text-neutral-600 mt-0.5 leading-relaxed">
                  {toast.description}
                </p>
              )}
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="text-neutral-400 hover:text-neutral-200 dark:text-neutral-500 dark:hover:text-neutral-900 transition-colors p-0.5 rounded"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
