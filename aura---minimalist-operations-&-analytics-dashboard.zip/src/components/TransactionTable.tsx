import React, { useState, useMemo } from 'react';
import {
  Search,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
  Download,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Layers,
  Check,
} from 'lucide-react';
import { Transaction, TransactionStatus } from '../types/dashboard';

interface TransactionTableProps {
  transactions: Transaction[];
  onSelectTransaction: (txn: Transaction) => void;
  density: 'comfortable' | 'compact';
  onToggleDensity: () => void;
  onExportFilteredCSV: (txns: Transaction[]) => void;
  onShowToast: (title: string, description?: string, type?: 'success' | 'info' | 'warning') => void;
}

type SortField = 'date' | 'amount' | 'customer' | 'status';
type SortDirection = 'asc' | 'desc';

export const TransactionTable: React.FC<TransactionTableProps> = ({
  transactions,
  onSelectTransaction,
  density,
  onToggleDensity,
  onExportFilteredCSV,
  onShowToast,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | TransactionStatus>('all');
  const [regionFilter, setRegionFilter] = useState<string>('all');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter & Search
  const filtered = useMemo(() => {
    return transactions.filter((txn) => {
      const matchStatus = statusFilter === 'all' || txn.status === statusFilter;
      const matchRegion = regionFilter === 'all' || txn.region === regionFilter;
      const matchCurrency = currencyFilter === 'all' || txn.currency === currencyFilter;
      const q = search.toLowerCase().trim();
      const matchSearch =
        !q ||
        txn.id.toLowerCase().includes(q) ||
        txn.customer.name.toLowerCase().includes(q) ||
        txn.customer.email.toLowerCase().includes(q) ||
        txn.plan.toLowerCase().includes(q) ||
        txn.paymentMethod.toLowerCase().includes(q);
      return matchStatus && matchRegion && matchCurrency && matchSearch;
    });
  }, [transactions, search, statusFilter, regionFilter, currencyFilter]);

  // Sorting
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let comparison = 0;
      if (sortField === 'date') {
        comparison = a.timestamp - b.timestamp;
      } else if (sortField === 'amount') {
        comparison = a.amount - b.amount;
      } else if (sortField === 'customer') {
        comparison = a.customer.name.localeCompare(b.customer.name);
      } else if (sortField === 'status') {
        comparison = a.status.localeCompare(b.status);
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [filtered, sortField, sortDirection]);

  // Pagination
  const totalPages = Math.ceil(sorted.length / itemsPerPage) || 1;
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return sorted.slice(start, start + itemsPerPage);
  }, [sorted, currentPage, itemsPerPage]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(new Set(paginated.map((t) => t.id)));
    } else {
      setSelectedIds(new Set());
    }
  };

  const toggleSelectOne = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const handleBatchVerify = () => {
    onShowToast(
      'Transactions Verified',
      `Marked ${selectedIds.size} transaction(s) as audited and reconciled.`,
      'success'
    );
    setSelectedIds(new Set());
  };

  const formatAmount = (amount: number, currency: string) => {
    const symbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : '£';
    return `${symbol}${amount.toLocaleString()}`;
  };

  // Unboxed status styling: subtle colored dot + plain legible text
  const renderStatus = (status: TransactionStatus) => {
    switch (status) {
      case 'settled':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-emerald-700 dark:text-emerald-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Settled
          </span>
        );
      case 'processing':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-amber-700 dark:text-amber-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
            In Escrow
          </span>
        );
      case 'refunded':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-neutral-600 dark:text-neutral-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 dark:bg-neutral-500" />
            Refunded
          </span>
        );
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-rose-700 dark:text-rose-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            Failed
          </span>
        );
    }
  };

  return (
    <div className="bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden transition-all">
      {/* Table Toolbar */}
      <div className="p-4 border-b border-neutral-200/80 dark:border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search & Status Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Search */}
          <div className="relative min-w-[200px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Filter by customer, ID..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800/80 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 rounded-lg border border-neutral-200/80 dark:border-neutral-700/80 focus:outline-hidden focus:ring-1 focus:ring-neutral-900 dark:focus:ring-neutral-200"
            />
          </div>

          {/* Status Tabs (Interactive buttons) */}
          <div className="flex items-center gap-1 p-0.5 bg-neutral-100 dark:bg-neutral-800/80 rounded-lg border border-neutral-200/60 dark:border-neutral-700/60 text-xs">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'settled', label: 'Settled' },
                { id: 'processing', label: 'Escrow' },
                { id: 'refunded', label: 'Refunded' },
                { id: 'failed', label: 'Failed' },
              ] as const
            ).map((tab) => {
              const active = statusFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setStatusFilter(tab.id);
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-50 shadow-xs font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Region Filter */}
          <select
            value={regionFilter}
            onChange={(e) => {
              setRegionFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2.5 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800/80 text-neutral-700 dark:text-neutral-300 rounded-lg border border-neutral-200/80 dark:border-neutral-700/80 focus:outline-hidden"
          >
            <option value="all">All Regions</option>
            <option value="US-East">US-East</option>
            <option value="EU-Central">EU-Central</option>
            <option value="UK-London">UK-London</option>
            <option value="APAC-Tokyo">APAC-Tokyo</option>
          </select>

          {/* Currency Filter */}
          <select
            value={currencyFilter}
            onChange={(e) => {
              setCurrencyFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-2.5 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800/80 text-neutral-700 dark:text-neutral-300 rounded-lg border border-neutral-200/80 dark:border-neutral-700/80 focus:outline-hidden"
          >
            <option value="all">All Currencies</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="GBP">GBP (£)</option>
          </select>
        </div>

        {/* Right Toolbar Actions */}
        <div className="flex items-center gap-2 self-end md:self-auto">
          {/* Bulk actions banner if rows selected */}
          {selectedIds.size > 0 && (
            <div className="flex items-center gap-2 mr-2 animate-in fade-in">
              <span className="text-xs text-neutral-500 font-mono tabular-nums">
                {selectedIds.size} selected
              </span>
              <button
                onClick={handleBatchVerify}
                className="px-2.5 py-1 text-xs font-medium bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-900 dark:text-neutral-100 rounded-md transition-colors"
              >
                Mark Audited
              </button>
            </div>
          )}

          {/* Density Toggle */}
          <button
            onClick={onToggleDensity}
            title={`Switch to ${density === 'comfortable' ? 'compact' : 'comfortable'} view`}
            className="p-1.5 text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-md transition-colors text-xs flex items-center gap-1"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline capitalize">{density}</span>
          </button>

          {/* Export Filtered CSV */}
          <button
            onClick={() => onExportFilteredCSV(filtered)}
            className="px-2.5 py-1 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-neutral-50 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200/80 dark:hover:bg-neutral-700/80 rounded-md transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Responsive Table Grid */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-neutral-200/80 dark:border-neutral-800 bg-neutral-50/70 dark:bg-neutral-800/40 text-neutral-500 dark:text-neutral-400 select-none">
              <th className="w-10 px-4 py-3">
                <input
                  type="checkbox"
                  checked={paginated.length > 0 && paginated.every((t) => selectedIds.has(t.id))}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900 cursor-pointer"
                  aria-label="Select all rows"
                />
              </th>

              {/* ID & Date */}
              <th
                onClick={() => toggleSort('date')}
                className="px-4 py-3 font-medium cursor-pointer hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>Reference & Date</span>
                  {sortField === 'date' ? (
                    sortDirection === 'asc' ? (
                      <ArrowUp className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              {/* Customer */}
              <th
                onClick={() => toggleSort('customer')}
                className="px-4 py-3 font-medium cursor-pointer hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>Customer / Organization</span>
                  {sortField === 'customer' ? (
                    sortDirection === 'asc' ? (
                      <ArrowUp className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              {/* Status */}
              <th
                onClick={() => toggleSort('status')}
                className="px-4 py-3 font-medium cursor-pointer hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
              >
                <div className="flex items-center gap-1">
                  <span>State</span>
                  {sortField === 'status' ? (
                    sortDirection === 'asc' ? (
                      <ArrowUp className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              {/* Plan & Method */}
              <th className="px-4 py-3 font-medium hidden lg:table-cell">Plan & Route</th>

              {/* Amount */}
              <th
                onClick={() => toggleSort('amount')}
                className="px-4 py-3 font-medium text-right cursor-pointer hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Gross Amount</span>
                  {sortField === 'amount' ? (
                    sortDirection === 'asc' ? (
                      <ArrowUp className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    ) : (
                      <ArrowDown className="w-3 h-3 text-neutral-900 dark:text-neutral-100" />
                    )
                  ) : (
                    <ArrowUpDown className="w-3 h-3 opacity-40" />
                  )}
                </div>
              </th>

              <th className="w-12 px-4 py-3 text-right">
                <span className="sr-only">Inspect</span>
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-neutral-200/60 dark:divide-neutral-800/60">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center text-neutral-500">
                  <div className="max-w-xs mx-auto space-y-1">
                    <p className="font-medium text-neutral-900 dark:text-neutral-100">
                      No matching transactions found
                    </p>
                    <p className="text-xs text-neutral-400">
                      Try adjusting your search terms or clearing the current filters.
                    </p>
                    <button
                      onClick={() => {
                        setSearch('');
                        setStatusFilter('all');
                      }}
                      className="mt-3 px-3 py-1.5 text-xs font-medium text-neutral-900 dark:text-neutral-100 bg-neutral-100 dark:bg-neutral-800 rounded-md"
                    >
                      Clear All Filters
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              paginated.map((txn) => {
                const isSelected = selectedIds.has(txn.id);
                const pyClass = density === 'comfortable' ? 'py-3.5' : 'py-2.5';

                return (
                  <tr
                    key={txn.id}
                    onClick={() => onSelectTransaction(txn)}
                    className={`cursor-pointer transition-colors group ${
                      isSelected
                        ? 'bg-neutral-100/70 dark:bg-neutral-800/70'
                        : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/40'
                    }`}
                  >
                    {/* Checkbox */}
                    <td
                      className={`px-4 ${pyClass}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSelectOne(txn.id);
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {}}
                        className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900 cursor-pointer"
                        aria-label={`Select transaction ${txn.id}`}
                      />
                    </td>

                    {/* Reference & Date */}
                    <td className={`px-4 ${pyClass}`}>
                      <div className="font-mono text-neutral-900 dark:text-neutral-100 font-medium">
                        {txn.id}
                      </div>
                      <div className="text-[11px] text-neutral-400 dark:text-neutral-500 font-mono tabular-nums">
                        {txn.date}
                      </div>
                    </td>

                    {/* Customer */}
                    <td className={`px-4 ${pyClass}`}>
                      <div className="font-medium text-neutral-900 dark:text-neutral-100 truncate max-w-[200px] sm:max-w-xs">
                        {txn.customer.name}
                      </div>
                      <div className="text-[11px] text-neutral-400 dark:text-neutral-500 truncate max-w-[200px] sm:max-w-xs">
                        {txn.customer.email}
                      </div>
                    </td>

                    {/* Status */}
                    <td className={`px-4 ${pyClass}`}>{renderStatus(txn.status)}</td>

                    {/* Plan & Route */}
                    <td className={`px-4 ${pyClass} hidden lg:table-cell`}>
                      <div className="text-neutral-800 dark:text-neutral-200">{txn.plan}</div>
                      <div className="text-[11px] text-neutral-400 dark:text-neutral-500">
                        {txn.paymentMethod}
                      </div>
                    </td>

                    {/* Gross Amount */}
                    <td className={`px-4 ${pyClass} text-right font-mono tabular-nums`}>
                      <div className="font-semibold text-neutral-900 dark:text-neutral-100 text-sm">
                        {formatAmount(txn.amount, txn.currency)}
                      </div>
                      <div className="text-[11px] text-neutral-400 dark:text-neutral-500">
                        net: {formatAmount(txn.amount - txn.fees, txn.currency)}
                      </div>
                    </td>

                    {/* Inspect arrow */}
                    <td className={`px-4 ${pyClass} text-right`}>
                      <ExternalLink className="w-3.5 h-3.5 text-neutral-400 group-hover:text-neutral-900 dark:group-hover:text-neutral-100 transition-colors inline" />
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3.5 border-t border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 bg-white dark:bg-neutral-900">
        <div>
          Showing{' '}
          <span className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
            {paginated.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}
          </span>{' '}
          to{' '}
          <span className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
            {Math.min(currentPage * itemsPerPage, sorted.length)}
          </span>{' '}
          of{' '}
          <span className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
            {sorted.length}
          </span>{' '}
          entries
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1 rounded-md border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 disabled:opacity-30 disabled:pointer-events-none hover:bg-neutral-50 dark:hover:bg-neutral-800"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100 px-1">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1 rounded-md border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 disabled:opacity-30 disabled:pointer-events-none hover:bg-neutral-50 dark:hover:bg-neutral-800"
            aria-label="Next page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
