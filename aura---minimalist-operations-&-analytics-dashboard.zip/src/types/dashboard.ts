export type TimePeriod = '24h' | '7d' | '30d' | '90d' | '12m';

export type MetricType = 'revenue' | 'mrr' | 'volume';

export type TransactionStatus = 'settled' | 'processing' | 'refunded' | 'failed';

export interface Transaction {
  id: string;
  customer: {
    name: string;
    email: string;
    avatar?: string;
  };
  amount: number;
  currency: 'USD' | 'EUR' | 'GBP';
  plan: 'Starter' | 'Professional' | 'Enterprise' | 'Scale Custom';
  status: TransactionStatus;
  date: string;
  timestamp: number;
  paymentMethod: 'Visa ···· 4242' | 'Mastercard ···· 8831' | 'ACH Direct' | 'SEPA Bank';
  fees: number;
  region: 'US-East' | 'EU-Central' | 'APAC-Tokyo' | 'UK-London';
}

export interface MetricSummary {
  title: string;
  value: string;
  rawNumeric: number;
  change: string;
  isPositive: boolean;
  timeframeText: string;
  sparkline: number[];
}

export interface ChartDataPoint {
  date: string;
  revenue: number;
  previousRevenue: number;
  mrr: number;
  volume: number;
}

export interface CustomerProfile {
  id: string;
  name: string;
  email: string;
  joinedDate: string;
  totalSpent: number;
  status: 'Active' | 'Paused' | 'At Risk';
  tier: 'Enterprise' | 'Professional' | 'Starter';
  lastPayment: string;
  region: string;
}

export interface RegionalPerformance {
  region: string;
  countryCode: string;
  share: number;
  revenue: number;
  growth: string;
  latencyMs: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'info' | 'warning';
}

export type WebhookStatus = 200 | 201 | 400 | 429 | 500;

export interface WebhookLog {
  id: string;
  event: 'payment.settled' | 'payment.failed' | 'payout.disbursed' | 'subscription.renewed' | 'customer.created';
  url: string;
  statusCode: WebhookStatus;
  durationMs: number;
  timestamp: string;
  attempts: number;
  payloadSummary: string;
}

export interface AnomalyAlert {
  id: string;
  severity: 'critical' | 'warning' | 'info';
  title: string;
  detail: string;
  metric: string;
  timestamp: string;
  actionRequired?: string;
  resolved: boolean;
}

export interface CustomDateRange {
  startDate: string;
  endDate: string;
}
